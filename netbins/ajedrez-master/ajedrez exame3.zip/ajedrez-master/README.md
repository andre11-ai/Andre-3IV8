Ajedrez
=======
Práctica para el laboratorio de ingeniería del software.
