/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ajedrez;

/**
 *
 * @author betico
 */
//public class Persona extends Jugador{
//
//    @Override
//    public void guardarMovimiento(String nombre, Movimientos mov) {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//    }
//
//   
//    
//}
