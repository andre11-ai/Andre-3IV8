package ajedrez;

public enum Color {
    blanca,
    negra
}
